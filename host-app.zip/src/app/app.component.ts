import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Host App';
  
  showEditor = false;

  url = 'http://localhost:8080/user-pol.js';

  toggleShowUserPolls() {
    this.showEditor = !this.showEditor;
  }
}