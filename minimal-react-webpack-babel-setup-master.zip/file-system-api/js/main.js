var fileSystem;

if (false || !!document.documentMode) {
  document.getElementById('exportButton').disabled = true;
  document.getElementById('initButton').disabled = true;

  document.getElementById('labelHeading').innerHTML = 'IE Browser!!';

  fileSystem = new ActiveXObject('Scripting.FileSystemObject');

  function createFile() {
    var fileName =
      document.getElementById('fileNameInput').value + '.txt';

    var a = fileSystem.CreateTextFile('c:\\demos\\' + fileName, true);
    a.close();
    appendToFile();
  }

  function appendToFile() {
    var fileName =
      document.getElementById('fileNameInput').value + '.txt';
    try {
      var data = document.getElementById('dataInput').value;

      if (data && data !== '') {
        var a = fileSystem.OpenTextFile(
          'c:\\demos\\' + fileName,
          8,
          0
        );
        a.WriteLine(data);
        console.log('Write completed.');
        a.close();
      } else {
        console.error('No data!!');
      }
    } catch (error) {
      console.error(error);
      createFile();
    }
  }
} else if (navigator.userAgent.indexOf('Chrome') !== -1) {
  document.getElementById('labelHeading').innerHTML = 'Chrome!!';

  window.requestFileSystem =
    window.requestFileSystem || window.webkitRequestFileSystem;

  function errorHandler(e) {
    var msg = '';
    console.log('Error: ' + e);
  }

  function exportData() {
    var fileName =
      document.getElementById('fileNameInput').value + '.txt';
    fileSystem.root.getFile(
      fileName,
      {},
      function (fileEntry) {
        fileEntry.file(function (file) {
          var reader = new FileReader();

          reader.onloadend = function (e) {
            download(this.result, fileName, 'text/plain');
          };
          reader.readAsText(file);
        }, errorHandler);
      },
      errorHandler
    );
  }

  function appendToFile() {
    var fileName =
      document.getElementById('fileNameInput').value + '.txt';
    var data = document.getElementById('dataInput').value;

    fileSystem.root.getFile(
      fileName,
      { create: true },
      function (fileEntry) {
        fileEntry.createWriter(function (fileWriter) {
          fileWriter.onwriteend = function (e) {
            console.log('Write completed.');
          };

          fileWriter.onerror = function (e) {
            console.log('Write failed: ' + e.toString());
          };

          fileWriter.seek(fileWriter.length);
          var blob = new Blob([data], {
            type: 'text/plain',
          });

          fileWriter.write(blob);
        }, errorHandler);
      },
      errorHandler
    );
  }

  function onInitFs() {
    var requestedBytes = 1024 * 1024 * 280;

    navigator.webkitPersistentStorage.requestQuota(
      requestedBytes,
      function (grantedBytes) {
        window.requestFileSystem(
          PERSISTENT,
          grantedBytes,
          initFileSystem,
          errorHandler
        );
        console.log('we were granted ', grantedBytes, 'bytes');
      },
      function (e) {
        console.log('Error', e);
      }
    );
  }
  function initFileSystem(fs) {
    var fileName =
      document.getElementById('fileNameInput').value + '.txt';
    fileSystem = fs;

    fileSystem.root.getFile(
      fileName,
      { create: true, exclusive: true },
      function (fileEntry) {
        fileEntry.isFile === true;
        fileEntry.name == fileName;
        fileEntry.fullPath == '/' + fileName;
      },
      errorHandler
    );
  }
}
