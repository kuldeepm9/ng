import Dexie from 'dexie';
import "dexie-export-import";

const db = new Dexie('ReactSampleDB');
db.version(1).stores({ todos: '++id' });

export default db;
