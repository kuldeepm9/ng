import Dexie from 'dexie';

var db;
var counter = 0;
const flushThreshold = 100;

self.addEventListener('message', function (e) {
  console.log('Command received: ' + JSON.stringify(e.data));

  switch (e.data.command) {
    case 'INIT':
      db = new Dexie('logsDB');

      db.version(1).stores({
        logs: '++id',
      });
      console.log('Database version: ' + db.verno);

      db.tables.forEach(function (table) {
        console.log('Found table: ' + table.name);
        console.log(
          'Table Schema: ' + JSON.stringify(table.schema, null, 4)
        );
      });
      break;

    case 'BULK_PUT':
      console.log('DB Insert started');
      db.logs
        .bulkPut(e.data.payload)
        .then(function (lastKey) {
          console.log('Last id was: ' + lastKey);
          if (lastKey >= counter + flushThreshold) {
            counter = lastKey;
            db.export().then(function (data) {
              const url = URL.createObjectURL(data);
              self.postMessage({ link: url });
            });
          }
        })
        .catch(Dexie.BulkError, function (e) {
          // Explicitely catching the bulkAdd() operation makes those successful
          // additions commit despite that there were errors.
          console.error(
            'Some raindrops did not succeed. However, ' +
              100000 -
              e.failures.length +
              ' raindrops was added successfully'
          );
        });

      console.log('DB Insert complete');
      break;

    case 'PUT':
      db.open().then(function () {
        db.logs.put(e.data.payload);
      });

      break;

    case 'DOWNLOAD':
      var dbs = new Dexie('test');
      dbs.version(1).stores({
        raindrops: 'id,position',
      });

      var drops = [];
      for (var i = 0; i < 10; ++i)
        drops.push({
          id: i,
          position: [Math.random(), Math.random(), Math.random()],
        });
        
      dbs.raindrops
        .bulkPut(drops)
        .then(function (lastKey) {
          console.log(
            'Done putting 100,000 raindrops all over the place'
          );
          console.log("Last raindrop's id was: " + lastKey); // Will be 100000.
        })
        .catch(Dexie.BulkError, function (e) {
          // Explicitely catching the bulkAdd() operation makes those successful
          // additions commit despite that there were errors.
          console.error(
            'Some raindrops did not succeed. However, ' +
              100000 -
              e.failures.length +
              ' raindrops was added successfully'
          );
        });

      // dbs.logs.orderBy('firstName').each(function (friend) {
      //   console.log(friend.firstName);
      // });
      // exportDB(db).then(function (data) {
      //   const url = URL.createObjectURL(data);
      //   self.postMessage({ link: url, data: data });
      // });

      break;

    case 'IMPORT':
      db.delete().then(function () {
        Dexie.import(e.data.payload);
      });
      break;

    case 'DELETE_DB':
      db.delete();
      break;

    default:
      console.error('Invalid command!!');
      break;
  }
});
