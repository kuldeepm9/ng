import React, { Component } from 'react';
import Worker from './log.worker.js';

const worker = new Worker();

class App extends Component {
  constructor() {
    super();
    this.insertData = this.insertData.bind(this);
    this.exportData = this.exportData.bind(this);
  }

  componentDidMount() {
    worker.postMessage({ command: 'INIT' });

    worker.onmessage = function (event) {
      console.log('received message' + event);
    };

    worker.addEventListener('message', function (event) {
      console.log('received message' + event);
    });
  }

  exportData() {
    console.log('Export Clicked');
    worker.postMessage({ command: 'DOWNLOAD' });

    // db.export().then(function (data) {
    //   var file_name = 'exported_data.json';

    //   if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    //     // for IE
    //     window.navigator.msSaveOrOpenBlob(data, file_name);
    //   } else {
    //     // for Non-IE (chrome, firefox etc.)
    //     var a = document.createElement('a');
    //     document.body.appendChild(a);
    //     a.style = 'display: none';
    //     var csvUrl = URL.createObjectURL(data);
    //     a.href = csvUrl;
    //     a.download = file_name;
    //     a.click();
    //     URL.revokeObjectURL(a.href);
    //     a.remove();
    //   }
    //   //self.postMessage({ link: url });
    // });
  }

  insertData() {
    const employeeData = [
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
      { firstName: 'John', lastName: 'Doe', age: 18 },
      { firstName: 'Foo', lastName: 'Bar', age: 21 },
    ];

    worker.postMessage({
      command: 'BULK_PUT',
      payload: employeeData,
    });
  }

  render() {
    return (
      <div className="App">
        <h3> ReactJS &gt; DexieJS &gt; Web Worker &gt; IndexedDB</h3>
        <button onClick={this.insertData}>Insert</button>
        <button onClick={this.importData}>Import</button>
        <button onClick={this.exportData}>Export</button>
        <button onClick={this.deleteDB}>Delete</button>
        <button onClick={this.autoInsert}>Auto Insert</button>
      </div>
    );
  }
}

export default App;
