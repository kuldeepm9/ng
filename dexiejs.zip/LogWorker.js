self.importScripts("https://unpkg.com/dexie@latest/dist/dexie.js");
self.importScripts("./dexie-export-import.js");

var db;
var counter = 0;
const flushThreshold = 100;

self.addEventListener("message", function (e) {
  switch (e.data.command) {
    case "INIT":
      db = new Dexie("testExampleWorker5");
      db.version(1).stores({
        accounts: "name, age, firstName, lastName",
      });

      db.version(2).stores({
        accounts: "name, age",
      });

      db.version(3).stores({ logs: "++id" });

      db.version(4).stores({ logs: "++id", accounts: null });

      db.version(9).stores({ logs: "++id", accounts: "name, age, address" });
      console.log("Database version: " + db.verno);

      db.tables.forEach(function (table) {
        console.log("Found table: " + table.name);
        console.log("Table Schema: " + JSON.stringify(table.schema, null, 4));
      });
      break;

    case "DOWNLOAD":
      db.export().then((data) => {
        const url = URL.createObjectURL(data);
        self.postMessage({ link: url });
      });

      break;

    case "BULK_PUT":
      db.open().then(() => {
        db.logs
          .bulkAdd(e.data.payload)
          .then(function (lastKey) {
            console.log("Last id was: " + lastKey);
            if (lastKey >= counter + flushThreshold) {
              counter = lastKey;
              db.export().then((data) => {
                const url = URL.createObjectURL(data);
                self.postMessage({ link: url });
              });
            }
          })
          .catch(Dexie.BulkError, function (e) {
            // Explicitely catching the bulkAdd() operation makes those successful
            // additions commit despite that there were errors.
            console.error(
              e.failures.length + " records were  added successfully."
            );
          });
      });
      break;

    case "PUT":
      db.open().then(() => {
        db.logs.put(e.data.payload);
      });

      break;

    case "IMPORT":
      db.delete().then(() => Dexie.import(e.data.payload));
      break;

    case "DELETE_DB":
      db.delete();
      break;

    default:
      console.error("Invalid command!!");
      break;
  }
});
