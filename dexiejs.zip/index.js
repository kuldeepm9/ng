const worker = new Worker("LogWorker.js");

worker.addEventListener(
  "message",
  function (e) {
    console.log("message from worker1", e);

    const a = document.createElement("a");
    a.href = e.data.link;
    a.download = "exported-data.json";
    a.click();

    window.URL.revokeObjectURL(e.data.link);
  },
  false
);

function onError(e) {
  console.error("Error: ", e);
}

worker.addEventListener("error", onError, false);

initDB.onclick = async () => {
  initializeControls();
  worker.postMessage({ command: "INIT" });
};

function initializeControls() {
  initDB.disabled = true;
  insertRecord.disabled = false;
  exportDB.disabled = false;
  autoInsert.disabled = false;
  deleteDB.disabled = false;
}

insertRecord.onclick = async () => {
  populateData();
};

exportDB.onclick = async () => {
  worker.postMessage({ command: "DOWNLOAD" });
};

autoInsert.onclick = async () => {
  setInterval(() => populateData(), 1000);
};

deleteDB.onclick = async () => {
  worker.postMessage({ command: "DELETE_DB" });
};

function populateData() {
  const employeeData = [
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
    { firstName: "John", lastName: "Doe", age: 18 },
    { firstName: "Foo", lastName: "Bar", age: 21 },
  ];
  const buffer = new ArrayBuffer(8);

  worker.postMessage({ command: "BULK_PUT", payload: employeeData }, [buffer]);
}

dropZoneDiv.ondragover = (event) => {
  event.stopPropagation();
  event.preventDefault();
  event.dataTransfer.dropEffect = "copy";
};

dropZoneDiv.ondrop = async (event) => {
  event.stopPropagation();
  event.preventDefault();
  const file = event.dataTransfer.files[0];
  try {
    if (!file) throw new Error(`Only files can be dropped here`);
    console.log("Importing " + file.name);
    worker.postMessage({ command: "IMPORT", payload: file });
    console.log("Import complete");
  } catch (error) {
    console.error("" + error);
  }
};
