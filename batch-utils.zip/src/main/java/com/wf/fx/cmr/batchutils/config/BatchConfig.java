package com.wf.fx.cmr.batchutils.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.bson.Document;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.data.MongoItemWriter;
import org.springframework.batch.item.data.builder.MongoItemWriterBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.wf.fx.cmr.batchutils.cmr.entity.Student;
import com.wf.fx.cmr.batchutils.processor.ItemToJsonProcessor;

@Configuration
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private ItemToJsonProcessor itemToJsonProcessor;

	@Autowired
	@Qualifier("cmrDataSource")
	private DataSource dataSource;

	@Autowired
	@Qualifier("rdsvcDataSource")
	private DataSource rdsvcDataSource;

	@Autowired
	@Qualifier("cmrEntityManagerFactory")
	private EntityManagerFactory cmrEntityManagerFactory;

	@Autowired
	@Qualifier("rdsvcEntityManagerFactory")
	private EntityManagerFactory rdsvcEntityManagerFactory;

	@Bean
	public Job chunkJob() {
		return jobBuilderFactory.get("Chunk Job").incrementer(new RunIdIncrementer()).start(mongoStep())
				.next(jdbcStep()).build();
	}

	@StepScope
	@Bean
	public MongoItemWriter<Document> mongoWriter() {
		return new MongoItemWriterBuilder<Document>().template(mongoTemplate).collection("student").build();
	}

	private Step mongoStep() {
		return stepBuilderFactory.get("Mongo Step").<Student, Document>chunk(10000).reader(jdbcCursorItemReader())
				.processor(itemToJsonProcessor).writer(mongoWriter()).build();
	}

	private Step jdbcStep() {
		return stepBuilderFactory.get("JDBC Step").<Student, Student>chunk(10000).reader(jdbcCursorItemReader())
				.writer(jdbcBatchItemWriter()).build();
	}

	public JdbcCursorItemReader<Student> jdbcCursorItemReader() {
		JdbcCursorItemReader<Student> jdbcCursorItemReader = new JdbcCursorItemReader<Student>();

		jdbcCursorItemReader.setDataSource(dataSource);
		jdbcCursorItemReader
				.setSql("select id, first_name as firstName, last_name as lastName," + "email from student");

		jdbcCursorItemReader.setRowMapper(new BeanPropertyRowMapper<Student>() {
			{
				setMappedClass(Student.class);
			}
		});

		return jdbcCursorItemReader;
	}

	@Bean
	public JdbcBatchItemWriter<Student> jdbcBatchItemWriter() {
		JdbcBatchItemWriter<Student> itemWriter = new JdbcBatchItemWriter<Student>();
		System.out.println();
		itemWriter.setSql(
				"INSERT INTO student(id, first_name, last_name, email) VALUES (:id, :firstName, :lastName, :email)");
		itemWriter.setDataSource(rdsvcDataSource);
		itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Student>());
		return itemWriter;
	}
}
