package com.wf.fx.cmr.batchutils;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableBatchProcessing
@ComponentScan({ "com.wf.fx.cmr.batchutils.config", "com.wf.fx.cmr.batchutils.listener",
		"com.wf.fx.cmr.batchutils.reader", "com.wf.fx.cmr.batchutils.processor", "com.wf.fx.cmr.batchutils.writer" })
public class BatchUtilsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchUtilsApplication.class, args);
	}
}
