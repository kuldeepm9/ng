package com.wf.fx.cmr.batchutils.processor;

import org.bson.Document;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wf.fx.cmr.batchutils.cmr.entity.Student;

@Component
public class ItemToJsonProcessor implements ItemProcessor<Student, Document> {

	@Override
	public Document process(Student item) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(item);
		Document doc = Document.parse(jsonString);
		return doc;
	}

}
