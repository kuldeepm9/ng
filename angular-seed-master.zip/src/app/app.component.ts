import { Component, Injector, Input, NgModuleFactoryLoader, SystemJsNgModuleLoader, ViewChild, ViewContainerRef } from '@angular/core';
import { WidgetComponent } from './widget/widget.component';

@Component({
  selector: 'user-root',
  template: `
  <p>Hello {{userName}}!!</p>
  <button (click)="loadModule()">Load fetched lazy component</button>
  <button (click)="unloadModule()">Unload Module</button>
  <hr>
  <div #vc></div>
  `,
  providers: [
    {
      provide: NgModuleFactoryLoader,
      useClass: SystemJsNgModuleLoader
    }
  ]
})
export class AppComponent {

  @Input("username")
  userName: string;

  @ViewChild('vc', { read: ViewContainerRef })
  _container: ViewContainerRef;

  moduleRef: any;

  showChild = false;

  constructor(private _injector: Injector,
    private loader: NgModuleFactoryLoader) {
  }


  loadModule() {
    this.loader.load('src/app/widget/widget.module#WidgetModule').then((factory) => {
      this.moduleRef = factory.create(this._injector);
      const resolver = this.moduleRef.componentFactoryResolver;

      const cmpFactory = resolver.resolveComponentFactory(WidgetComponent);
      this._container.createComponent(cmpFactory);
    });
  }

  unloadModule() {
    this.moduleRef.destroy();
  }

}