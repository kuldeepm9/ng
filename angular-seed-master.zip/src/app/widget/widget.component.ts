import { Component, Input } from '@angular/core';

@Component({
    selector: 'widget-root',
    template: '<p>Hello, I am a Widget</p>'
})
export class WidgetComponent {

}
