import { NgModule } from "@angular/core";
import { WidgetComponent } from "./widget.component";

@NgModule({
    declarations: [WidgetComponent],
    bootstrap: [WidgetComponent],
    entryComponents: [WidgetComponent]
})
export class WidgetModule {
}