var concat = require('concat-files');

concat([
    './dist/polyfills.js',
    './dist/runtime.js',
    './dist/main.js'
], './dist/user-pol.js', function (err) {
    if (err) throw err
    console.log('done');
});